package bthao.com.database.model;

public class Subject {
    public int subjectID;
    public String subjectName;
    public Subject(int subjectID, String subjectName) {
        this.subjectID = subjectID;
        this.subjectName = subjectName;
    }

    @Override
    public String toString() {
        return subjectName;
    }
}
