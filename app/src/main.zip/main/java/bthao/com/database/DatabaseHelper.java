package bthao.com.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

import bthao.com.database.model.Document;
import bthao.com.database.model.Schedule;
import bthao.com.database.model.Subject;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "ql_tailieu.db";
    private static final int DB_VERSION = 3;  // <-- TĂNG VERSION LÊN 2 ĐỂ THÊM CỘT MỚI

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // 1. Bảng Môn học - BỔ SUNG ĐỦ CÁC CỘT THEO ERD
        db.execSQL("CREATE TABLE MonHoc (" +
                "maMonHoc INTEGER PRIMARY KEY, " +
                "tenMonHoc TEXT NOT NULL, " +
                "soTinChi INTEGER DEFAULT 3, " +
                "hocKy INTEGER, " +
                "soTietHoc INTEGER DEFAULT 45)");

        // 2. Bảng Tài liệu - ĐÚNG THEO ERD + thêm loaiTep như bạn đang dùng
        db.execSQL("CREATE TABLE TaiLieu (" +
                "maTaiLieu INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "tenTaiLieu TEXT NOT NULL, " +
                "duongDan TEXT, " +
                "loaiTep TEXT DEFAULT 'Tài liệu học tập', " +
                "MonHocmaMonHoc INTEGER, " +
                "FOREIGN KEY(MonHocmaMonHoc) REFERENCES MonHoc(maMonHoc) ON DELETE CASCADE)");

        // 3. Bảng Mục tiêu điểm - MỚI
        db.execSQL("CREATE TABLE MucTieuDiem (" +
                "maMucTieu INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "MucTieuMonHoc TEXT, " +        // ví dụ: "Đạt 8.0", "Học bổng", "Giỏi"
                "MucTieu INTEGER, " +           // điểm mục tiêu (8, 9, 10...)
                "MonHocmaMonHoc INTEGER, " +
                "FOREIGN KEY(MonHocmaMonHoc) REFERENCES MonHoc(maMonHoc) ON DELETE CASCADE)");

        // 4. Bảng Điểm số - MỚI
        db.execSQL("CREATE TABLE DiemSo (" +
                "maDiem INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "MonHocmaMonHoc INTEGER, " +
                "diemTX1 REAL, " +
                "diemTX2 REAL, " +
                "diemGK REAL, " +
                "diemCK REAL, " +
                "diemTB REAL, " +               // sẽ tính tự động hoặc nhập tay
                "xepLoai TEXT, " +              // Giỏi, Khá, Trung bình...
                "heSoTX1 REAL DEFAULT 1, " +
                "heSoTX2 REAL DEFAULT 1, " +
                "heSoGK REAL DEFAULT 2, " +
                "heSoCK REAL DEFAULT 3, " +
                "FOREIGN KEY(MonHocmaMonHoc) REFERENCES MonHoc(maMonHoc) ON DELETE CASCADE)");

        // 5. Bảng Thời gian biểu - MỚI
        db.execSQL("CREATE TABLE ThoiGianBieu (" +
                "maThoiGianBieu INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "MonHocmaMonHoc INTEGER, " +
                "tieuDe TEXT, " +                  // Thứ 2, Thứ 3...
                "noiDung TEXT, " +        // Tiết bắt đầu (1-12)
                "ngay TEXT, " +            // Số tiết học liên tiếp
                "gioBatDau TEXT, " +
                "gioKetThuc TEXT, " +
                "diaDiem TEXT, " +
                "ghiChu TEXT, " +
                "loaiLich TEXT, " +
                "FOREIGN KEY(MonHocmaMonHoc) REFERENCES MonHoc(maMonHoc) ON DELETE CASCADE)");

        // Dữ liệu mẫu môn học (đã bổ sung đầy đủ cột)
        db.execSQL("INSERT INTO MonHoc (maMonHoc, tenMonHoc, soTinChi, hocKy, soTietHoc) VALUES " +
                "(1, 'Toán cao cấp', 4, 1, 60), " +
                "(2, 'Vật lý đại cương', 3, 1, 45), " +
                "(3, 'Lập trình Java', 4, 2, 60), " +
                "(4, 'Cơ sở dữ liệu', 3, 2, 45), " +
                "(5, 'Tiếng Anh 1', 3, 1, 45)");

        db.execSQL("INSERT INTO ThoiGianBieu (tieuDe, noiDung, ngay, gioBatDau, gioKetThuc, diaDiem, ghiChu, loaiLich) VALUES " +
                "('Java Lecture', 'Lecture', '2025-11-10', '2025-11-10 08:00', '2025-11-10 10:00', 'A101', 'Bring laptop', 'Lecture'), " +
                "('Team Meeting', 'Meeting', '2025-11-10', '2025-11-10 14:00', '2025-11-10 15:30', 'B202', 'Project update', 'Meeting'), " +
                "('Database Lab', 'Lab', '2025-11-11', '2025-11-11 09:00', '2025-11-11 11:00', 'Lab 301', 'SQL', 'Lab'), " +
                "('Math Exam', 'Exam', '2025-11-12', '2025-11-12 13:00', '2025-11-12 15:00', 'Hall C', 'Calculator allowed', 'Exam'), " +
                "('English Class', 'Lecture', '2025-11-13', '2025-11-13 10:00', '2025-11-13 12:00', 'D105', 'Unit 5', 'Lecture'), " +
                "('Project Deadline', 'Deadline', '2025-11-15', '2025-11-15 23:59', '2025-11-15 23:59', 'Online', 'Submit on Moodle', 'Deadline')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 3) {  // <-- Đang nâng lên version 3 (đầy đủ 5 bảng)
            // Xóa bảng cũ nếu tồn tại
            db.execSQL("DROP TABLE IF EXISTS ThoiGianBieu");
            db.execSQL("DROP TABLE IF EXISTS DiemSo");
            db.execSQL("DROP TABLE IF EXISTS MucTieuDiem");
            db.execSQL("DROP TABLE IF EXISTS TaiLieu");
            db.execSQL("DROP TABLE IF EXISTS MonHoc");

            // Tạo lại toàn bộ theo thiết kế mới
            onCreate(db);
        }
    }
    public List<Subject> getAllMonHoc() {
        List<Subject> list = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT maMonHoc, tenMonHoc FROM MonHoc ORDER BY tenMonHoc", null);
        while (c.moveToNext()) {
            list.add(new Subject(c.getInt(0), c.getString(1))); // maMonHoc, tenMonHoc
        }
        c.close();
        return list;
    }

    // Lấy tất cả tài liệu (có join tên môn học + loaiTep)
    public List<Document> getAllTaiLieu() {
        List<Document> list = new ArrayList<>();
        String sql = "SELECT t.maTaiLieu, t.tenTaiLieu, t.duongDan, t.loaiTep, t.MonHocmaMonHoc, m.tenMonHoc " +
                "FROM TaiLieu t LEFT JOIN MonHoc m ON t.MonHocmaMonHoc = m.maMonHoc " +
                "ORDER BY t.tenTaiLieu";
        Cursor c = getReadableDatabase().rawQuery(sql, null);
        while (c.moveToNext()) {
            Document tl = new Document();
            tl.setDocumentID(c.getInt(0));
            tl.setDocumentName(c.getString(1));
            tl.setPath(c.getString(2));
            tl.setFileType(c.getString(3) != null ? c.getString(3) : "Tài liệu học tập"); // tránh null
            tl.setSubjectID(c.getInt(4));
            tl.setSubjectName(c.getString(5));
            list.add(tl);
        }
        c.close();
        return list;

    }

    // Thêm tài liệu mới
    public long insertTaiLieu(Document tl) {
        ContentValues cv = new ContentValues();
        cv.put("tenTaiLieu", tl.getDocumentName());
        cv.put("duongDan", tl.getPath());
        cv.put("loaiTep", tl.getFileType());           // <-- LƯU LOẠI TÀI LIỆU
        cv.put("MonHocmaMonHoc", tl.getSubjectID());
        return getWritableDatabase().insert("TaiLieu", null, cv);
    }

    // Cập nhật tài liệu
    public boolean updateTaiLieu(Document tl) {
        ContentValues cv = new ContentValues();
        cv.put("tenTaiLieu", tl.getDocumentName());
        cv.put("duongDan", tl.getPath());
        cv.put("loaiTep", tl.getFileType());           // <-- CẬP NHẬT LOẠI TÀI LIỆU
        cv.put("MonHocmaMonHoc", tl.getSubjectID());
        int rows = getWritableDatabase().update("TaiLieu", cv, "maTaiLieu = ?",
                new String[]{String.valueOf(tl.getDocumentID())});
        return rows > 0;
    }

    // Xóa tài liệu
    public boolean deleteTaiLieu(int maTaiLieu) {
        int rows = getWritableDatabase().delete("TaiLieu", "maTaiLieu = ?",
                new String[]{String.valueOf(maTaiLieu)});
        return rows > 0;
    }

    // Thêm vào DatabaseHelper.java

    // SỬA HÀM NÀY – ĐÚNG TÊN CỘT
    public long insertMonHoc(String tenMon) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("tenMonHoc", tenMon.trim());  // ĐÚNG: tenMonHoc
        long id = db.insert("MonHoc", null, values);
        // Không close db ở đây vì SQLiteOpenHelper tự quản lý
        return id;
    }

    // SỬA HÀM NÀY – ĐÚNG TÊN CỘT
    public Subject getSubjectByName(String tenMon) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("MonHoc",
                new String[]{"maMonHoc", "tenMonHoc"},     // ĐÚNG tên cột
                "tenMonHoc = ?",
                new String[]{tenMon.trim()},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            Subject s = new Subject(
                    cursor.getInt(cursor.getColumnIndexOrThrow("maMonHoc")),   // ĐÚNG
                    cursor.getString(cursor.getColumnIndexOrThrow("tenMonHoc")) // ĐÚNG
            );
            cursor.close();
            return s;
        }
        if (cursor != null) cursor.close();
        return null;
    }

    // 1. LẤY LỊCH THEO NGÀY
    public List<Schedule> getScheduleByDate(String date) {
        List<Schedule> list = new ArrayList<>();
        String sql = "SELECT maThoiGianBieu, tieuDe, noiDung, ngay, gioBatDau, gioKetThuc, diaDiem, ghiChu, loaiLich " +
                "FROM ThoiGianBieu WHERE ngay = ? ORDER BY gioBatDau";
        Cursor c = getReadableDatabase().rawQuery(sql, new String[]{date});

        if (c != null && c.moveToFirst()) {
            do {
                Schedule s = new Schedule();
                s.setId(c.getInt(0));
                s.setTitle(c.getString(1));
                s.setContent(c.getString(2));
                s.setDate(c.getString(3));
                s.setStartTime(c.getString(4));
                s.setEndTime(c.getString(5));
                s.setLocation(c.getString(6));
                s.setNote(c.getString(7));
                s.setType(c.getString(8));
                list.add(s);
            } while (c.moveToNext());
        }
        if (c != null) c.close();
        return list;
    }

    // 2. THÊM LỊCH
    public long insertSchedule(Schedule s) {
        ContentValues cv = new ContentValues();
        cv.put("tieuDe", s.getTitle() != null ? s.getTitle() : "No Title");
        cv.put("noiDung", s.getContent() != null ? s.getContent() : "");
        cv.put("ngay", s.getDate() != null ? s.getDate() : "");
        cv.put("gioBatDau", s.getStartTime() != null ? s.getStartTime() : "");
        cv.put("gioKetThuc", s.getEndTime() != null ? s.getEndTime() : "");
        cv.put("diaDiem", s.getLocation() != null ? s.getLocation() : "");
        cv.put("ghiChu", s.getNote() != null ? s.getNote() : "");
        cv.put("loaiLich", s.getType() != null ? s.getType() : "Event");
        return getWritableDatabase().insert("ThoiGianBieu", null, cv);
    }

    // 3. CẬP NHẬT LỊCH
    public boolean updateSchedule(Schedule s) {
        ContentValues cv = new ContentValues();
        cv.put("tieuDe", s.getTitle());
        cv.put("noiDung", s.getContent());
        cv.put("ngay", s.getDate());
        cv.put("gioBatDau", s.getStartTime());
        cv.put("gioKetThuc", s.getEndTime());
        cv.put("diaDiem", s.getLocation());
        cv.put("ghiChu", s.getNote());
        cv.put("loaiLich", s.getType());
        return getWritableDatabase().update("ThoiGianBieu", cv,
                "maThoiGianBieu = ?", new String[]{String.valueOf(s.getId())}) > 0;
    }

    // 4. XÓA LỊCH
    public boolean deleteSchedule(int id) {
        return getWritableDatabase().delete("ThoiGianBieu",
                "maThoiGianBieu = ?", new String[]{String.valueOf(id)}) > 0;
    }

}