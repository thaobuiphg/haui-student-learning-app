package bthao.com.dialog;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.fragment.app.DialogFragment;
import java.util.Calendar;
import bthao.com.R;
import bthao.com.database.model.Schedule;

public class AddScheduleDialog extends DialogFragment {

    private OnScheduleSaved listener;

    public interface OnScheduleSaved {
        void onSave(Schedule s);
    }

    public AddScheduleDialog(OnScheduleSaved listener) {
        this.listener = listener;
    }

    @Override
    public android.app.Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        var view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_edit_schedule, null);

        EditText etTitle = view.findViewById(R.id.etTitle);
        EditText etDate = view.findViewById(R.id.etDate);
        EditText etStart = view.findViewById(R.id.etStartTime);
        EditText etEnd = view.findViewById(R.id.etEndTime);
        EditText etLocation = view.findViewById(R.id.etLocation);
        EditText etNote = view.findViewById(R.id.etNote);

        Calendar cal = Calendar.getInstance();
        etDate.setText(String.format("%02d/%02d/%d",
                cal.get(Calendar.DAY_OF_MONTH), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.YEAR)));

        setupDateTimePickers(etDate, etStart, etEnd, cal);

        builder.setView(view)
                .setTitle("Thêm sự kiện mới")
                .setPositiveButton("Thêm", null)
                .setNegativeButton("Hủy", null);

        AlertDialog dialog = builder.create();
        dialog.show();

        Button btnSave = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        btnSave.setOnClickListener(v -> {
            Schedule s = validateAndCreateSchedule(etTitle, etDate, etStart, etEnd, etLocation, etNote);
            if (s != null) {
                listener.onSave(s);
                Toast.makeText(getContext(), "Đã thêm: " + s.getTitle(), Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            } else {
                Toast.makeText(getContext(), "Vui lòng điền đầy đủ!", Toast.LENGTH_SHORT).show();
            }
        });

        return dialog;
    }

    private void setupDateTimePickers(EditText etDate, EditText etStart, EditText etEnd, Calendar cal) {
        etDate.setOnClickListener(v -> new DatePickerDialog(getContext(),
                (v2, y, m, d) -> etDate.setText(String.format("%02d/%02d/%d", d, m + 1, y)),
                cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show());

        etStart.setOnClickListener(v -> new TimePickerDialog(getContext(),
                (v2, h, m) -> etStart.setText(String.format("%02d:%02d", h, m)),
                cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show());

        etEnd.setOnClickListener(v -> new TimePickerDialog(getContext(),
                (v2, h, m) -> etEnd.setText(String.format("%02d:%02d", h, m)),
                cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show());
    }

    private Schedule validateAndCreateSchedule(EditText... fields) {
        String title = fields[0].getText().toString().trim();
        String dateInput = fields[1].getText().toString(); // MM/dd/yyyy
        String start = fields[2].getText().toString();
        String end = fields[3].getText().toString();

        if (title.isEmpty() || dateInput.isEmpty() || start.isEmpty() || end.isEmpty()) {
            return null;
        }

        // CHUYỂN MM/dd/yyyy → yyyy-MM-dd
        String[] parts = dateInput.split("/");
        if (parts.length != 3) return null;

        String formattedDate;
        try {
            int day = Integer.parseInt(parts[0]);
            int month = Integer.parseInt(parts[1]);
            int year = Integer.parseInt(parts[2]);
            formattedDate = String.format("%d-%02d-%02d", year, month, day); // yyyy-MM-dd
        } catch (Exception e) {
            return null;
        }

        Schedule s = new Schedule();
        s.setTitle(title);
        s.setDate(formattedDate); // ĐÚNG ĐỊNH DẠNG!
        s.setStartTime(formattedDate + " " + start);
        s.setEndTime(formattedDate + " " + end);
        s.setLocation(fields[4].getText().toString().trim());
        s.setNote(fields[5].getText().toString().trim());
        s.setType("Event");
        return s;
    }
}