package bthao.com.dialog;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.EditText;
import androidx.fragment.app.DialogFragment;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import bthao.com.R;
import bthao.com.database.model.Schedule;

public class EditScheduleDialog extends DialogFragment {

    private Schedule schedule;
    private OnScheduleSaved listener;

    public interface OnScheduleSaved {
        void onSave(Schedule s);
    }

    public EditScheduleDialog(Schedule schedule, OnScheduleSaved listener) {
        this.schedule = schedule;
        this.listener = listener;
    }

    @Override
    public android.app.Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        var view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_edit_schedule, null);

        EditText etTitle = view.findViewById(R.id.etTitle);
        EditText etDate = view.findViewById(R.id.etDate);
        EditText etStart = view.findViewById(R.id.etStartTime);
        EditText etEnd = view.findViewById(R.id.etEndTime);
        EditText etLocation = view.findViewById(R.id.etLocation);
        EditText etNote = view.findViewById(R.id.etNote);

        // ĐỔ DỮ LIỆU CŨ
        etTitle.setText(schedule.getTitle());
        etDate.setText(schedule.getDate().replace("-", "/"));
        etStart.setText(extractTime(schedule.getStartTime()));
        etEnd.setText(extractTime(schedule.getEndTime()));
        etLocation.setText(schedule.getLocation());
        etNote.setText(schedule.getNote());

        Calendar cal = parseDate(schedule.getDate());
        setupDateTimePickers(etDate, etStart, etEnd, cal);

        builder.setView(view)
                .setTitle("Chỉnh sửa sự kiện")
                .setPositiveButton("Lưu", null)
                .setNegativeButton("Hủy", null);

        AlertDialog dialog = builder.create();
        dialog.show();

        Button btnSave = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        btnSave.setOnClickListener(v -> {
            Schedule s = validateAndCreateSchedule(etTitle, etDate, etStart, etEnd, etLocation, etNote);
            if (s != null) {
                s.setId(schedule.getId()); // GIỮ ID CŨ
                listener.onSave(s);
                dialog.dismiss();
            }
        });

        return dialog;
    }

    // === HÀM HỖ TRỢ ===
    private String extractTime(String fullTime) {
        return fullTime != null && fullTime.length() >= 16 ? fullTime.substring(11, 16) : "00:00";
    }

    private Calendar parseDate(String dateStr) {
        Calendar cal = Calendar.getInstance();
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            cal.setTime(sdf.parse(dateStr));
        } catch (Exception e) {
            // fallback
        }
        return cal;
    }

    private void setupDateTimePickers(EditText etDate, EditText etStart, EditText etEnd, Calendar cal) {
        etDate.setOnClickListener(v -> new DatePickerDialog(getContext(),
                (v2, y, m, d) -> etDate.setText(String.format("%02d/%02d/%d", d, m + 1, y)),
                cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show());

        etStart.setOnClickListener(v -> new TimePickerDialog(getContext(),
                (v2, h, m) -> etStart.setText(String.format("%02d:%02d", h, m)),
                cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show());

        etEnd.setOnClickListener(v -> new TimePickerDialog(getContext(),
                (v2, h, m) -> etEnd.setText(String.format("%02d:%02d", h, m)),
                cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show());
    }

    private Schedule validateAndCreateSchedule(EditText... fields) {
        String title = fields[0].getText().toString().trim();
        String date = fields[1].getText().toString().replace("/", "-");
        String start = fields[2].getText().toString();
        String end = fields[3].getText().toString();

        if (title.isEmpty() || date.isEmpty() || start.isEmpty() || end.isEmpty()) {
            return null;
        }

        Schedule s = new Schedule();
        s.setTitle(title);
        s.setDate(date);
        s.setStartTime(date + " " + start);
        s.setEndTime(date + " " + end);
        s.setLocation(fields[4].getText().toString().trim());
        s.setNote(fields[5].getText().toString().trim());
        s.setType("Event");
        return s;
    }
}