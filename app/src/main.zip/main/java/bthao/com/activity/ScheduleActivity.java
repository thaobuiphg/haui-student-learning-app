package bthao.com.activity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import bthao.com.R;
import bthao.com.adapter.ScheduleAdapter;
import bthao.com.database.DatabaseHelper;
import bthao.com.database.model.Schedule;
import bthao.com.dialog.AddScheduleDialog;
import bthao.com.dialog.EditScheduleDialog;

public class ScheduleActivity extends AppCompatActivity implements ScheduleAdapter.OnScheduleListener {

    private DatabaseHelper db;
    private ScheduleAdapter adapter;
    private TextView tvWeek;
    private Calendar currentCalendar;
    private SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    private SimpleDateFormat sdfDisplay = new SimpleDateFormat("MMM dd", Locale.getDefault());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule);

        db = new DatabaseHelper(this);
        currentCalendar = Calendar.getInstance();

        RecyclerView rv = findViewById(R.id.rvSchedule);
        adapter = new ScheduleAdapter(this);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(adapter);

        tvWeek = findViewById(R.id.tvWeek);
        Button btnPrev = findViewById(R.id.btnPrevWeek);
        Button btnNext = findViewById(R.id.btnNextWeek);
        FloatingActionButton btnAdd = findViewById(R.id.btnAdd);

        btnPrev.setOnClickListener(v -> {
            currentCalendar.add(Calendar.DAY_OF_YEAR, -7);
            updateWeek();
        });

        btnNext.setOnClickListener(v -> {
            currentCalendar.add(Calendar.DAY_OF_YEAR, 7);
            updateWeek();
        });

        btnAdd.setOnClickListener(v -> {
            new AddScheduleDialog(s -> {
                db.insertSchedule(s);
                updateWeek();
            }).show(getSupportFragmentManager(), "add");
        });

        updateWeek();
    }

    private void updateWeek() {
        Calendar start = getStartOfWeek(currentCalendar);
        Calendar end = getEndOfWeek(currentCalendar);

        List<Schedule> allInWeek = new ArrayList<>();
        Calendar temp = (Calendar) start.clone();

        while (!temp.after(end)) {
            String dateStr = sdfDate.format(temp.getTime());
            List<Schedule> dayList = db.getScheduleByDate(dateStr);
            if (dayList != null) {
                allInWeek.addAll(dayList);
            }
            temp.add(Calendar.DAY_OF_YEAR, 1);
        }

        tvWeek.setText(sdfDisplay.format(start.getTime()) + " - " + sdfDisplay.format(end.getTime()));
        adapter.setData(allInWeek); // tự động notify
    }

    private Calendar getStartOfWeek(Calendar cal) {
        Calendar c = (Calendar) cal.clone();
        c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        return c;
    }

    private Calendar getEndOfWeek(Calendar cal) {
        Calendar c = (Calendar) cal.clone();
        c.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
        return c;
    }

    // SỬA
    @Override
    public void onEdit(Schedule s) {
        new EditScheduleDialog(s, updated -> {
            db.updateSchedule(updated);
            updateWeek();
        }).show(getSupportFragmentManager(), "edit");
    }

    @Override
    public void onDelete(Schedule s) {
        db.deleteSchedule(s.getId());
        updateWeek();
    }
}