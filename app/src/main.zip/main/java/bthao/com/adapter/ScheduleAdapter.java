package bthao.com.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import bthao.com.R;
import bthao.com.database.model.Schedule;

public class ScheduleAdapter extends RecyclerView.Adapter<ScheduleAdapter.ViewHolder> {

    private List<Schedule> list = new ArrayList<>();
    private OnScheduleListener listener;
    private SimpleDateFormat dateInput = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    private SimpleDateFormat dateOutput = new SimpleDateFormat("EEE, MMM dd", Locale.getDefault());

    public ScheduleAdapter(OnScheduleListener listener) {
        this.listener = listener;
    }

    public void setData(List<Schedule> newList) {
        this.list = newList != null ? newList : new ArrayList<>();
        notifyDataSetChanged(); // THÊM DÒNG NÀY!
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_schedule, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int p) {
        Schedule s = list.get(p);

        h.tvTitle.setText(s.getTitle() != null ? s.getTitle() : "No Title");

        // HIỂN THỊ NGÀY
        String displayDate = formatDate(s.getDate());
        h.tvDate.setText(displayDate);

        // GIỜ
        h.tvTime.setText(extractTime(s.getStartTime()) + " - " + extractTime(s.getEndTime()));

        h.tvLocation.setText(s.getLocation() != null ? s.getLocation() : "No Location");
        h.tvNote.setText(s.getNote() != null ? s.getNote() : "No Note");

        // LONG PRESS → MENU SỬA / XÓA
        h.itemView.setOnLongClickListener(v -> {
            new AlertDialog.Builder(v.getContext())
                    .setTitle(s.getTitle())
                    .setItems(new String[]{"Sửa", "Xóa"}, (dialog, which) -> {
                        if (which == 0) {
                            listener.onEdit(s);
                        } else {
                            new AlertDialog.Builder(v.getContext())
                                    .setMessage("Xóa \"" + s.getTitle() + "\"?")
                                    .setPositiveButton("Xóa", (d, w) -> listener.onDelete(s))
                                    .setNegativeButton("Hủy", null)
                                    .show();
                        }
                    })
                    .show();
            return true;
        });
    }

    // HÀM HỖ TRỢ
    private String extractTime(String fullTime) {
        if (fullTime == null || fullTime.length() < 16) return "??:??";
        return fullTime.substring(11, 16);
    }

    private String formatDate(String dateStr) {
        if (dateStr == null || !dateStr.matches("\\d{4}-\\d{2}-\\d{2}")) return "Unknown";
        try {
            return dateOutput.format(dateInput.parse(dateStr));
        } catch (Exception e) {
            return dateStr;
        }
    }
    @Override
    public int getItemCount() { return list.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvDate, tvTime, tvLocation, tvNote;
        ViewHolder(View v) {
            super(v);
            tvTitle = v.findViewById(R.id.tvTitle);
            tvDate = v.findViewById(R.id.tvDate);
            tvTime = v.findViewById(R.id.tvTime);
            tvLocation = v.findViewById(R.id.tvLocation);
            tvNote = v.findViewById(R.id.tvNote);
        }
    }

    public interface OnScheduleListener {
        void onEdit(Schedule s);
        void onDelete(Schedule s);
    }
}